import React from "react";
import App from "./BTTH/Lab2/B3/App";
export default function MainApp() 
{
    return  <App/>;
}
