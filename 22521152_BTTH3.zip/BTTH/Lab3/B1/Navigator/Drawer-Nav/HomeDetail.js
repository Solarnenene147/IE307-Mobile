import React from 'react';
import { View, Text } from 'react-native';

const NotiDetail = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Home Detail screen</Text>
    </View>
  );
};

export default NotiDetail;
