import React from "react";
import App from "./BTTH/Lab3/B2/App";
export default function MainApp() 
{
    return  <App/>;
}
